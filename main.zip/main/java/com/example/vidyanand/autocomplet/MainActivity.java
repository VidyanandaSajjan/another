package com.example.vidyanand.autocomplet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
{
    AutoCompleteTextView like;

    String[] parts={"eyes","nose","leg","lips","heart"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        like=(AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);

        like.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                ArrayAdapter<String> adapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_dropdown_item_1line,parts);
            like.setThreshold(1);
                like.setAdapter(adapter);
            }
        });
    }
}
